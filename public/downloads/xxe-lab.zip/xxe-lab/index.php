<?php

$xml = file_get_contents("php://input");

$dom = new DOMDocument();
$dom->loadXML($xml, LIBXML_NOENT | LIBXML_DTDLOAD);

echo $dom->saveXML();
?>
