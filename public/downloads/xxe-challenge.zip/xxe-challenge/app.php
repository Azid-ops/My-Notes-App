<?php

libxml_disable_entity_loader(false);

function log_event($msg) {
    file_put_contents("runtime/activity.log", $msg . "\n", FILE_APPEND);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $xml = file_get_contents("php://input");

    $dom = new DOMDocument();

    // Intentionally unsafe parsing
    $dom->loadXML($xml, LIBXML_NOENT | LIBXML_DTDLOAD);

    // Allow XInclude for modular imports
    $dom->xinclude();

    // Simulate processing user import
    $user = $dom->getElementsByTagName("username")->item(0);
    $email = $dom->getElementsByTagName("email")->item(0);

    if ($user && $email) {
        echo "<h3>User Imported:</h3>";
        echo "<p>Username: " . htmlspecialchars($user->nodeValue) . "</p>";
        echo "<p>Email: " . htmlspecialchars($email->nodeValue) . "</p>";
    } else {
        echo "<h3>Invalid XML Structure</h3>";
    }

    // Log that import occurred (Blind vector exists here)
    log_event("Import processed at " . date("Y-m-d H:i:s"));

    exit;
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Secure XML Import Service</title>
</head>
<body>
<h2>Secure XML Import Service</h2>
<p>Submit XML to import user profile data.</p>
<p>Expected format:</p>
<pre>
&lt;user&gt;
    &lt;username&gt;john&lt;/username&gt;
    &lt;email&gt;john@example.com&lt;/email&gt;
&lt;/user&gt;
</pre>
</body>
</html>
